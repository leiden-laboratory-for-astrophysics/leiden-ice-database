Clazz.declarePackage ("JS");
Clazz.load (["JS.LayoutManager"], "JS.FlowLayout", null, function () {
c$ = Clazz.declareType (JS, "FlowLayout", JS.LayoutManager);
});
